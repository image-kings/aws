# Interested in hosting your own version of this class?
Please email `architecting-for-ml@amazon.com` to contact local experts who can lead you through this course. 

For each new project you would like to evaluate, you'll need ~3-4 technical people to build a POC during the scope of the 3-day period. You will also need to make sure you have access to the dataset that is relevant to your project. 

As of December 2018, there is no cost for the course. We prefer to run in your AWS account so you can keep everything you build, but if necessary you can run in our lab environment.



