*****************************************************************************
 libspatialindex
*****************************************************************************


:Author: Marios Hadjieleftheriou
:Contact: mhadji@gmail.com
:Revision: 1.8.0
:Date: 11/30/2012

See http://libspatialindex.org for full documentation.