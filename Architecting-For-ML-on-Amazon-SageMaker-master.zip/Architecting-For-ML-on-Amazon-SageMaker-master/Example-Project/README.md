# User Guide
Generally, this example code can be followed by starting in the ETL directory. 
- Analyze Crimes
- Analyze Weather
- Join

Next, move into the modeling directory.
- Format into X's and Y's
- Multi-class modeling.
